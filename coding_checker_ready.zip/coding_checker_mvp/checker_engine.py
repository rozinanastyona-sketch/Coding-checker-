from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
import json
import re
import shutil

import pandas as pd
import yaml
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font
from openpyxl.utils import get_column_letter


@dataclass
class EventRow:
    original_index: int
    data: Dict[str, Any]
    behavior: str
    modifiers: List[str]
    comment: str


@dataclass
class Utterance:
    """
    A single coded utterance: one "Communicative Intent Present/Absent" event
    plus all the coding rows and start/stop markers grouped around it (see
    segment_utterances()).

    Transcription conventions inside the Comment cell on the CI row
    (per the AAC Lab Operational Definitions doc, "Utterance Boundaries &
    Transcription Conventions" / "Number of Relevant Symbols" sections):
      - Square brackets `[...]` mark symbols the coder judged IRRELEVANT
        (e.g. "DOG [IN ON] UNDER CAR" -> DOG, UNDER, CAR are relevant; IN, ON
        are not). This is a human judgment call (mazes, non-adjacent repeats,
        context-dependent relevance - see "Number of Relevant Symbols" in the
        Operational Definitions) and is NOT mechanically re-derivable from
        the bracketed text alone, so this engine does not try to compute
        Number of Symbols / Number of Relevant Symbols from the transcript.
        Those are taken directly from the "Number of Symbols" / "Number of
        Relevant Symbols" behavior rows the coder entered, same as every
        other coded value, and compared against the key the same way.
      - A leading dash (e.g. "-S", "-ING", "-'S") marks a bound morpheme
        attached to the previous symbol, not a separate word.
      - Parentheses are sometimes used for a coder's own aside/clarification
        (e.g. "HIPPO -S (BARN)").
    None of the above characters are stripped or specially parsed anywhere in
    this file - comment text is always treated as opaque display text
    (see clean_text/utterance_text below) specifically so that bracket/dash
    notation always survives unchanged into Review_Notes and the "Utterance
    #" transcript shown to the reviewer.
    """
    uid: int
    rows: List[EventRow] = field(default_factory=list)
    boundary_unclear: bool = False

    @property
    def first_row_index(self) -> int:
        return self.rows[0].original_index if self.rows else -1

    @property
    def last_row_index(self) -> int:
        return self.rows[-1].original_index if self.rows else -1

    @property
    def utterance_text(self) -> str:
        return self._text_info()[0]

    @property
    def text_is_partial(self) -> bool:
        """True when the transcript was recovered from a 'USV: ...' note.

        A USV note records only the subject-verb combination (e.g.
        "USV: I PUT"), not the full utterance, so such text is a prefix /
        subset of the real transcript and must be matched by containment,
        not full-string similarity, during alignment.
        """
        return self._text_info()[1]

    def _text_info(self) -> Tuple[str, bool]:
        usv_prefix = "USV:"
        for row in self.rows:
            if behavior_equals(row.behavior, "Communicative Intent Present"):
                c = clean_text(row.comment)
                if not c:
                    continue
                if c.upper().startswith(usv_prefix):
                    # Some coders combine the USV note and the transcript in
                    # one cell (e.g. "USV: I PUT") instead of putting the
                    # note on the SV row and the transcript on the CI row.
                    # Strip the prefix and keep whatever transcript remains
                    # instead of discarding the whole comment.
                    remainder = c[len(usv_prefix):].strip()
                    if remainder:
                        return remainder, True
                    continue
                return c, False
        return "", False


@dataclass
class Issue:
    kind: str
    color: str
    message: str
    row_index: Optional[int] = None
    insert_after_row_index: Optional[int] = None
    missing_behavior: Optional[str] = None
    expected: Optional[str] = None
    utterance_id: Optional[int] = None


def load_grammar(path: str | Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    if pd.isna(value):
        return ""
    return str(value).strip()


def norm(value: Any) -> str:
    return re.sub(r"\s+", " ", clean_text(value)).strip()


def build_alias_map(grammar: Dict[str, Any]) -> Dict[str, str]:
    alias_to_canonical = {}
    for canonical, aliases in grammar.get("aliases", {}).items():
        alias_to_canonical[norm(canonical).lower()] = canonical
        for alias in aliases or []:
            alias_to_canonical[norm(alias).lower()] = canonical
    return alias_to_canonical


def canonicalize(value: Any, alias_map: Dict[str, str]) -> str:
    v = norm(value)
    return alias_map.get(v.lower(), v)


def behavior_key(value: Any) -> str:
    """Case/whitespace-insensitive key for comparing Behavior values.

    Observer XT exports are not consistent about casing across an ethogram
    (e.g. real exports contain "utterance start" but also "Word Order Score"
    and "Parts of Speech Present" with different capitalization than what
    was originally typed into grammar.yaml). Every place that used to compare
    behaviors with `==` or `in` against grammar-defined names now goes
    through behavior_equals()/behavior_in() instead, so a future casing
    mismatch degrades gracefully instead of silently breaking matching.
    """
    return norm(value).lower()


def behavior_equals(a: Any, b: Any) -> bool:
    return behavior_key(a) == behavior_key(b)


def behavior_in(value: Any, targets: Iterable[Any]) -> bool:
    v = behavior_key(value)
    return any(v == behavior_key(t) for t in targets)


def read_excel_first_sheet_or_named(path_or_file: Any, sheet_name: Optional[str] = None) -> pd.DataFrame:
    if sheet_name is None:
        return pd.read_excel(path_or_file, sheet_name=0)
    return pd.read_excel(path_or_file, sheet_name=sheet_name)


def prepare_dataframe(df: pd.DataFrame, grammar: Dict[str, Any]) -> pd.DataFrame:
    """Keep required columns + all Modifier* columns. Do not assume how many modifiers exist."""
    df = df.copy()
    required = grammar["columns"]["required"]
    modifier_prefix = grammar["columns"]["modifier_columns"]["detect_by_prefix"]

    # Observer files may contain whitespace in column names.
    df.columns = [str(c).strip() for c in df.columns]

    missing_required = [c for c in required if c not in df.columns]
    if missing_required:
        raise ValueError(f"Missing required columns: {missing_required}")

    modifier_cols = [c for c in df.columns if str(c).strip().startswith(modifier_prefix)]
    keep_cols = required + modifier_cols
    return df[keep_cols].copy()


def row_to_event(row: pd.Series, idx: int, grammar: Dict[str, Any], alias_map: Dict[str, str]) -> EventRow:
    modifier_prefix = grammar["columns"]["modifier_columns"]["detect_by_prefix"]
    modifier_cols = [c for c in row.index if str(c).startswith(modifier_prefix)]
    ignored = {norm(m).lower() for m in grammar["columns"]["modifier_columns"].get("ignored_modifiers", []) or []}
    modifiers = []
    for col in modifier_cols:
        val = clean_text(row.get(col))
        if not val:
            continue
        canon = canonicalize(val, alias_map)
        if norm(canon).lower() in ignored:
            # Not part of the graded coding scheme (see grammar.yaml
            # ignored_modifiers). Dropped here so it can never produce a
            # "Missing/Extra modifiers" issue or affect the Scores sheet,
            # regardless of whether a given key file still contains it.
            continue
        modifiers.append(canon)

    behavior = canonicalize(row.get("Behavior"), alias_map)
    comment = clean_text(row.get("Comment"))
    data = {str(k): row.get(k) for k in row.index}
    data["Behavior"] = behavior
    data["Comment"] = comment
    return EventRow(original_index=idx, data=data, behavior=behavior, modifiers=modifiers, comment=comment)


def dataframe_to_events(df: pd.DataFrame, grammar: Dict[str, Any]) -> List[EventRow]:
    alias_map = build_alias_map(grammar)
    return [row_to_event(row, idx, grammar, alias_map) for idx, row in df.iterrows()]


def is_ignored_comment(comment: str, grammar: Dict[str, Any]) -> bool:
    prefixes = grammar["utterance_detection"].get("ignore_comment_prefixes", [])
    c = clean_text(comment)
    return any(c.upper().startswith(p.upper()) for p in prefixes)


def segment_utterances(events: List[EventRow], grammar: Dict[str, Any]) -> List[Utterance]:
    """
    Utterance segmentation, anchored on Communicative Intent Present/Absent.

    Why CI-anchored instead of start/stop-anchored:
    Real Observer XT exports contain duplicate/misplaced "Utterance start" /
    "Utterance stop" events (confirmed pattern: duplicate starts back to
    back, a stray start+stop pair inserted before an utterance's real stop,
    duplicate stops after the real stop). grammar.yaml's own
    `duplicate_start_stop` note already calls this an "Observer app bug, not
    student error" - but a start/stop-driven state machine can't tell a
    duplicate marker from a real boundary. In practice it closed real
    utterances early (marking them boundary_unclear) and manufactured empty
    phantom utterances in between, roughly doubling the utterance count and
    desyncing the 1:1 index alignment compare_files() relies on - which then
    cascades into unrelated false MISSING/EXTRA/wrong-modifier flags for the
    rest of the session.

    Communicative Intent Present/Absent is logged exactly once per real
    utterance (this is already how Utterance.utterance_text finds its text),
    so it is used as the anchor here. Start/stop rows are still kept (for
    write_annotated_excel highlighting and so comparable_rows can exclude
    them from scoring) but are attached to whichever utterance they're
    adjacent to rather than used to open/close utterances.
    """
    start_b = grammar["utterance_detection"]["start_behavior"]
    stop_b = grammar["utterance_detection"]["stop_behavior"]
    intents = grammar["utterance_detection"]["intent_behaviors"]

    utterances: List[Utterance] = []
    current: Optional[Utterance] = None
    pending_markers: List[EventRow] = []  # start/stop rows seen before any utterance is open
    uid = 1

    for ev in events:
        b = ev.behavior

        if behavior_in(b, intents):
            if current is not None:
                utterances.append(current)
            current = Utterance(uid=uid, rows=list(pending_markers))
            uid += 1
            pending_markers = []
            current.rows.append(ev)
            continue

        if behavior_in(b, (start_b, stop_b)):
            if current is not None:
                current.rows.append(ev)
            else:
                pending_markers.append(ev)
            continue

        # Any other coding row.
        if current is None:
            # A coding row with no CI seen yet is genuinely ambiguous: flag for review.
            current = Utterance(uid=uid, rows=list(pending_markers), boundary_unclear=True)
            uid += 1
            pending_markers = []
        current.rows.append(ev)

    if current is not None:
        current.rows.extend(pending_markers)
        utterances.append(current)
    elif pending_markers:
        utterances.append(Utterance(uid=uid, rows=pending_markers, boundary_unclear=True))

    return utterances


def get_sequence_entry(grammar: Dict[str, Any], behavior: str) -> Optional[Dict[str, Any]]:
    for entry in grammar["sequence"]:
        if behavior_in(behavior, entry.get("behaviors", [])):
            return entry
    return None


def comparable_rows(utt: Utterance, grammar: Dict[str, Any]) -> List[EventRow]:
    start_b = grammar["utterance_detection"]["start_behavior"]
    stop_b = grammar["utterance_detection"]["stop_behavior"]
    return [r for r in utt.rows if not behavior_in(r.behavior, (start_b, stop_b))]


def find_row_by_group(utt: Utterance, entry: Dict[str, Any], grammar: Dict[str, Any]) -> Optional[EventRow]:
    behaviors = entry.get("behaviors", [])
    for row in comparable_rows(utt, grammar):
        if behavior_in(row.behavior, behaviors):
            return row
    return None


def modifier_set(row: Optional[EventRow]) -> set[str]:
    if row is None:
        return set()
    return {norm(m) for m in row.modifiers if norm(m)}


def validate_row_against_key(student_row: EventRow, key_row: EventRow, entry: Dict[str, Any]) -> Optional[str]:
    if not behavior_equals(student_row.behavior, key_row.behavior):
        return f"Expected Behavior: {key_row.behavior}; found: {student_row.behavior}"

    expected_mods = modifier_set(key_row)
    student_mods = modifier_set(student_row)
    if expected_mods != student_mods:
        missing = sorted(expected_mods - student_mods)
        extra = sorted(student_mods - expected_mods)
        parts = []
        if missing:
            parts.append("Missing modifiers: " + ", ".join(missing))
        if extra:
            parts.append("Extra modifiers: " + ", ".join(extra))
        return "; ".join(parts)
    return None


def check_usv_rule(student_utt: Utterance, grammar: Dict[str, Any]) -> Optional[Issue]:
    for rule in grammar.get("special_rules", []):
        if rule.get("name") != "USV comment required":
            continue
        for row in comparable_rows(student_utt, grammar):
            if not behavior_equals(row.behavior, rule.get("if_behavior")):
                continue
            mods = modifier_set(row)
            required = set(rule.get("required_modifiers", []))
            if required.issubset(mods):
                prefix = rule.get("then_comment_must_start_with", "USV:")
                # USV note may be in the same row or in any row inside the same utterance.
                has_usv = any(clean_text(r.comment).upper().startswith(prefix.upper()) for r in student_utt.rows)
                if not has_usv:
                    return Issue(
                        kind="usv_missing_note",
                        color=grammar["colors"]["usv_missing_note"],
                        message=f"SV is Lexical + Unique, but Comment does not contain '{prefix}'",
                        row_index=row.original_index,
                        utterance_id=student_utt.uid,
                    )
    return None


def compare_utterances(student_utt: Utterance, key_utt: Utterance, grammar: Dict[str, Any]) -> List[Issue]:
    issues: List[Issue] = []
    red = grammar["colors"]["error"]
    purple = grammar["colors"]["boundary_unclear"]

    if student_utt.boundary_unclear:
        issues.append(Issue(
            kind="boundary_unclear",
            color=purple,
            message="Utterance boundary could not be confidently detected; check manually.",
            row_index=student_utt.first_row_index,
            utterance_id=student_utt.uid,
        ))

    previous_student_row: Optional[EventRow] = None
    for entry in grammar["sequence"]:
        key_row = find_row_by_group(key_utt, entry, grammar)
        student_row = find_row_by_group(student_utt, entry, grammar)

        if key_row is None:
            # Reference does not require this group for this utterance.
            continue

        if student_row is None:
            insert_after = previous_student_row.original_index if previous_student_row else student_utt.first_row_index
            expected = key_row.behavior
            if key_row.modifiers:
                expected += " | " + " | ".join(key_row.modifiers)
            issues.append(Issue(
                kind="missing",
                color=red,
                message=f"MISSING: {expected}",
                insert_after_row_index=insert_after,
                missing_behavior=key_row.behavior,
                expected=expected,
                utterance_id=student_utt.uid,
            ))
            continue

        msg = validate_row_against_key(student_row, key_row, entry)
        if msg:
            issues.append(Issue(
                kind="wrong",
                color=red,
                message=msg,
                row_index=student_row.original_index,
                utterance_id=student_utt.uid,
            ))

        previous_student_row = student_row

    # Extra rows: student has known code groups that key does not have in that utterance.
    for srow in comparable_rows(student_utt, grammar):
        entry = get_sequence_entry(grammar, srow.behavior)
        if entry is None:
            continue
        krow = find_row_by_group(key_utt, entry, grammar)
        if krow is None:
            issues.append(Issue(
                kind="extra",
                color=red,
                message=f"EXTRA code not expected in key utterance: {srow.behavior}",
                row_index=srow.original_index,
                utterance_id=student_utt.uid,
            ))

    usv_issue = check_usv_rule(student_utt, grammar)
    if usv_issue:
        issues.append(usv_issue)

    return issues


def _match_text(s: str) -> str:
    """Normalize an utterance transcript for alignment matching only.

    Brackets/parentheses are stripped here because the coder's
    relevance-notation may legitimately differ between student and key
    ("I BUY [SHAKE]" vs "I BUY SHAKE" is the same utterance); this
    normalization is used ONLY to decide which utterances correspond, never
    for scoring or display.
    """
    t = re.sub(r"[\[\]\(\)]", " ", s or "")
    t = re.sub(r"\s+", " ", t).strip().upper()
    return t


def _text_similarity(a: str, b: str, a_partial: bool = False, b_partial: bool = False) -> float:
    from difflib import SequenceMatcher
    na, nb = _match_text(a), _match_text(b)
    if not na and not nb:
        return 0.5  # both untranscribed: weak evidence, allow positional matching
    if not na or not nb:
        return 0.0
    ratio = SequenceMatcher(None, na, nb).ratio()
    # A 'USV: ...' note records only the subject-verb combination, not the
    # full transcript. If the partial side's words all appear (in order) in
    # the other side's transcript, treat that as strong evidence of a match.
    if a_partial or b_partial:
        short, long_ = (na, nb) if a_partial else (nb, na)
        short_words = short.split()
        long_words = long_.split()
        it = iter(long_words)
        contained = all(w in it for w in short_words)
        if contained:
            ratio = max(ratio, 0.7)
    return ratio


def align_utterances(
    student_utts: List[Utterance],
    key_utts: List[Utterance],
    min_similarity: float = 0.6,
) -> List[Tuple[Optional[int], Optional[int]]]:
    """
    Align student utterances to key utterances by transcript similarity
    (Needleman-Wunsch style dynamic programming, gaps allowed on both sides).

    Returns a list of (student_index, key_index) pairs in order; None on one
    side means that utterance has no counterpart (student skipped a key
    utterance, or coded an extra one). This replaces the old
    "student_utts[i] vs key_utts[i]" pairing, where a single skipped
    utterance early in the session desynchronized every comparison after it
    and produced a cascade of false MISSING/EXTRA/wrong-modifier flags.
    """
    n, m = len(student_utts), len(key_utts)
    GAP = -0.05  # small penalty so the DP prefers matching over gapping

    # score[i][j] = best total for first i student utts vs first j key utts
    score = [[0.0] * (m + 1) for _ in range(n + 1)]
    move = [[None] * (m + 1) for _ in range(n + 1)]  # 'd'iag, 'u'p (skip student), 'l'eft (skip key)
    for i in range(1, n + 1):
        score[i][0] = score[i - 1][0] + GAP
        move[i][0] = "u"
    for j in range(1, m + 1):
        score[0][j] = score[0][j - 1] + GAP
        move[0][j] = "l"

    sims = [[_text_similarity(
                student_utts[i].utterance_text, key_utts[j].utterance_text,
                a_partial=student_utts[i].text_is_partial,
                b_partial=key_utts[j].text_is_partial)
             for j in range(m)] for i in range(n)]

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            sim = sims[i - 1][j - 1]
            diag = score[i - 1][j - 1] + (sim if sim >= min_similarity else GAP * 2)
            up = score[i - 1][j] + GAP
            left = score[i][j - 1] + GAP
            best = max(diag, up, left)
            score[i][j] = best
            move[i][j] = "d" if best == diag else ("u" if best == up else "l")

    pairs: List[Tuple[Optional[int], Optional[int]]] = []
    i, j = n, m
    while i > 0 or j > 0:
        mv = move[i][j]
        if mv == "d":
            si, kj = i - 1, j - 1
            if sims[si][kj] >= min_similarity:
                pairs.append((si, kj))
            else:
                # diagonal was taken as a double-gap: report both as unmatched
                pairs.append((si, None))
                pairs.append((None, kj))
            i, j = i - 1, j - 1
        elif mv == "u":
            pairs.append((i - 1, None))
            i -= 1
        else:
            pairs.append((None, j - 1))
            j -= 1
    pairs.reverse()
    return pairs


def compare_files_with_alignment(
    student_df: pd.DataFrame, key_df: pd.DataFrame, grammar: Dict[str, Any]
) -> Tuple[List[Issue], List[Utterance], List[Utterance], List[Tuple[Optional[int], Optional[int]]]]:
    student_prepared = prepare_dataframe(student_df, grammar)
    key_prepared = prepare_dataframe(key_df, grammar)

    student_utts = segment_utterances(dataframe_to_events(student_prepared, grammar), grammar)
    key_utts = segment_utterances(dataframe_to_events(key_prepared, grammar), grammar)

    pairs = align_utterances(student_utts, key_utts)

    issues: List[Issue] = []
    red = grammar["colors"]["error"]
    purple = grammar["colors"]["boundary_unclear"]

    last_matched_student_row = 0
    for s_idx, k_idx in pairs:
        if s_idx is not None and k_idx is not None:
            issues.extend(compare_utterances(student_utts[s_idx], key_utts[k_idx], grammar))
            last_matched_student_row = student_utts[s_idx].last_row_index
        elif k_idx is not None:
            key_utt = key_utts[k_idx]
            issues.append(Issue(
                kind="missing_utterance",
                color=red,
                message=f"MISSING whole utterance from key (key utt #{key_utt.uid}): {key_utt.utterance_text or 'no text'}",
                insert_after_row_index=last_matched_student_row,
            ))
        else:
            student_utt = student_utts[s_idx]
            issues.append(Issue(
                kind="extra_utterance",
                color=purple,
                message="Extra student utterance (no matching utterance in key); check manually.",
                row_index=student_utt.first_row_index,
                utterance_id=student_utt.uid,
            ))
            last_matched_student_row = student_utt.last_row_index

    return issues, student_utts, key_utts, pairs


def compare_files(student_df: pd.DataFrame, key_df: pd.DataFrame, grammar: Dict[str, Any]) -> Tuple[List[Issue], List[Utterance], List[Utterance]]:
    issues, student_utts, key_utts, _ = compare_files_with_alignment(student_df, key_df, grammar)
    return issues, student_utts, key_utts


def extract_first_utterances(df: pd.DataFrame, grammar: Dict[str, Any], n: int = 5) -> List[str]:
    prepared = prepare_dataframe(df, grammar)
    utts = segment_utterances(dataframe_to_events(prepared, grammar), grammar)
    texts = []
    for utt in utts:
        text = utt.utterance_text
        if text and not is_ignored_comment(text, grammar):
            texts.append(text)
        if len(texts) >= n:
            break
    return texts


def create_reference_passport(reference_path: str | Path, grammar: Dict[str, Any], display_name: Optional[str] = None, sheet_name: Optional[str] = None) -> Dict[str, Any]:
    df = read_excel_first_sheet_or_named(reference_path, sheet_name=sheet_name)
    first_n = grammar.get("output", {}).get("first_utterances_in_passport", 5)
    first_utts = extract_first_utterances(df, grammar, n=first_n)
    prepared = prepare_dataframe(df, grammar)
    utts = segment_utterances(dataframe_to_events(prepared, grammar), grammar)
    path = Path(reference_path)
    return {
        "id": path.stem,
        "display_name": display_name or path.stem,
        "file_name": path.name,
        "sheet_name": sheet_name,
        "utterance_count": len(utts),
        "first_utterances": first_utts,
    }


def add_reference_to_library(uploaded_path: str | Path, library_dir: str | Path, grammar: Dict[str, Any], display_name: Optional[str] = None, sheet_name: Optional[str] = None) -> Dict[str, Any]:
    library = Path(library_dir)
    library.mkdir(parents=True, exist_ok=True)
    src = Path(uploaded_path)
    dst = library / src.name
    if src.resolve() != dst.resolve():
        shutil.copy2(src, dst)
    passport = create_reference_passport(dst, grammar, display_name=display_name, sheet_name=sheet_name)
    passport_path = dst.with_suffix(".json")
    passport_path.write_text(json.dumps(passport, ensure_ascii=False, indent=2), encoding="utf-8")
    return passport


def index_reference_folder(library_dir: str | Path, grammar: Dict[str, Any]) -> List[str]:
    """Create passports for any .xlsx in the library folder that lacks one.

    The app reads the library from the .json passports, not from the .xlsx
    files themselves. Previously a passport was only written when a file was
    uploaded through the Reference Library page, so key files copied straight
    into reference_keys/ were invisible to the app and had to be re-uploaded.
    This scans the folder and indexes anything new, so dropping files into
    reference_keys/ is enough (uploading through the UI still works too).

    Returns the display names of newly indexed files.
    """
    library = Path(library_dir)
    if not library.exists():
        return []
    newly_indexed: List[str] = []
    for xlsx in sorted(library.glob("*.xlsx")):
        if xlsx.name.startswith("~$"):  # Excel lock file
            continue
        passport_path = xlsx.with_suffix(".json")
        if passport_path.exists():
            continue
        try:
            passport = create_reference_passport(xlsx, grammar)
            passport_path.write_text(json.dumps(passport, ensure_ascii=False, indent=2), encoding="utf-8")
            newly_indexed.append(passport.get("display_name", xlsx.stem))
        except Exception:
            # A malformed/unrelated xlsx in the folder shouldn't break startup.
            continue
    return newly_indexed


def load_reference_passports(library_dir: str | Path) -> List[Dict[str, Any]]:
    library = Path(library_dir)
    if not library.exists():
        return []
    passports = []
    for p in sorted(library.glob("*.json")):
        try:
            passports.append(json.loads(p.read_text(encoding="utf-8")))
        except Exception:
            continue
    return passports


def score_passport_match(student_first: List[str], passport: Dict[str, Any]) -> int:
    ref_first = passport.get("first_utterances", [])
    score = 0
    for a, b in zip(student_first, ref_first):
        if norm(a).lower() == norm(b).lower():
            score += 2
        elif norm(a).lower() in norm(b).lower() or norm(b).lower() in norm(a).lower():
            score += 1
    return score


def suggest_references(student_df: pd.DataFrame, grammar: Dict[str, Any], library_dir: str | Path, top_k: int = 3) -> Tuple[List[str], List[Dict[str, Any]]]:
    first_n = grammar.get("output", {}).get("first_utterances_in_passport", 5)
    student_first = extract_first_utterances(student_df, grammar, n=first_n)
    passports = load_reference_passports(library_dir)
    ranked = sorted(passports, key=lambda p: score_passport_match(student_first, p), reverse=True)
    return student_first, ranked[:top_k]


# Report column label for each grammar sequence group, in report order.
# Matches the lab's manual score-sheet format (see Study_1_Video1_Scores_*):
# one row per KEY utterance, one column per coding category, 1 = student
# matches the key for that category, 0 = any discrepancy (wrong behavior,
# wrong/missing/extra modifiers, or missing code row). An utterance the
# student did not code at all scores 0 in every category.
SCORES_COLUMN_ORDER: List[Tuple[str, str]] = [
    ("Listing", "Listing"),
    ("Communicative Intent", "Communicative intent"),
    ("Imitative", "Imitativeness"),
    ("Independent Aided Utterances", "Independence"),
    ("Number of Symbols", "# of symbols"),
    ("Number of Relevant Symbols", "# of relevant symbols"),
    ("Word Order", "Word order"),
    ("SV", "SV"),
    ("Parts of Speech", "Parts of speech"),
    ("Inflectional Morphemes", "Inflectional morph"),
    ("Grammatical Intent", "Grammatical Intent"),
]


def _issue_group(issue: Issue, student_utt: Utterance, key_utt: Utterance, grammar: Dict[str, Any]) -> Optional[str]:
    """Determine which sequence group an issue belongs to."""
    if issue.kind == "missing" and issue.missing_behavior:
        entry = get_sequence_entry(grammar, issue.missing_behavior)
        return entry["group"] if entry else None
    if issue.row_index is not None:
        for row in student_utt.rows:
            if row.original_index == issue.row_index:
                entry = get_sequence_entry(grammar, row.behavior)
                return entry["group"] if entry else None
    return None


def build_scores_rows(
    student_utts: List[Utterance],
    key_utts: List[Utterance],
    pairs: List[Tuple[Optional[int], Optional[int]]],
    issues: List[Issue],
    grammar: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """One dict per KEY utterance with 1/0 per category, in key order.

    Rows carry a private "_missing" flag (True when the student did not code
    that key utterance at all). Only those rows get highlighted in the Scores
    sheet; individual 0s are left unshaded since the numbers speak for
    themselves and shading every 0 made the sheet hard to read.
    """
    # Issues per student utterance uid, bucketed by group.
    failed_groups_by_uid: Dict[int, set] = {}
    utt_by_uid = {u.uid: u for u in student_utts}
    key_by_student_uid: Dict[int, Utterance] = {}
    for s_idx, k_idx in pairs:
        if s_idx is not None and k_idx is not None:
            key_by_student_uid[student_utts[s_idx].uid] = key_utts[k_idx]

    for issue in issues:
        if issue.utterance_id is None or issue.kind in ("boundary_unclear", "usv_missing_note", "extra_utterance"):
            # usv_missing_note is a note-quality reminder (orange), not a
            # key mismatch; boundary/extra flags are handled separately.
            continue
        s_utt = utt_by_uid.get(issue.utterance_id)
        k_utt = key_by_student_uid.get(issue.utterance_id)
        if s_utt is None or k_utt is None:
            continue
        group = _issue_group(issue, s_utt, k_utt, grammar)
        if group:
            failed_groups_by_uid.setdefault(issue.utterance_id, set()).add(group)

    student_by_key_uid: Dict[int, Utterance] = {}
    for s_idx, k_idx in pairs:
        if s_idx is not None and k_idx is not None:
            student_by_key_uid[key_utts[k_idx].uid] = student_utts[s_idx]

    rows: List[Dict[str, Any]] = []
    for number, key_utt in enumerate(key_utts, start=1):
        time_val = ""
        for r in key_utt.rows:
            if behavior_in(r.behavior, grammar["utterance_detection"]["intent_behaviors"]):
                time_val = clean_text(r.data.get("Time_Relative_hms"))
                break
        row: Dict[str, Any] = {
            "Number": number,
            "Time_Relative_hms": time_val,
            "Utterance": key_utt.utterance_text,
        }
        student_utt = student_by_key_uid.get(key_utt.uid)
        failed = failed_groups_by_uid.get(student_utt.uid, set()) if student_utt else None
        row["_missing"] = student_utt is None
        for group, label in SCORES_COLUMN_ORDER:
            if student_utt is None:
                row[label] = 0  # whole utterance missing from student coding
            else:
                row[label] = 0 if group in failed else 1
        rows.append(row)
    return rows


def write_scores_sheet(wb, scores_rows: List[Dict[str, Any]]) -> None:
    """Append a 'Scores' sheet in the lab's manual score-sheet layout."""
    if "Scores" in wb.sheetnames:
        del wb["Scores"]
    ws = wb.create_sheet("Scores")

    headers = ["Number", "Time_Relative_hms", "Utterance"] + [label for _, label in SCORES_COLUMN_ORDER]
    for col, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = Font(bold=True)

    missing_fill = PatternFill("solid", fgColor="FF9999")
    for r, row in enumerate(scores_rows, start=2):
        is_missing = row.get("_missing", False)
        for col, h in enumerate(headers, start=1):
            cell = ws.cell(row=r, column=col, value=row.get(h))
            if is_missing:
                # Student never coded this key utterance: shade the whole row.
                cell.fill = missing_fill

    n = len(scores_rows)
    if n:
        total_row = n + 3
        pct_row = n + 4
        ws.cell(row=total_row, column=3, value="Total").font = Font(bold=True)
        ws.cell(row=pct_row, column=3, value="Percentage").font = Font(bold=True)
        for col_offset, (_, label) in enumerate(SCORES_COLUMN_ORDER):
            col = 4 + col_offset
            total = sum(r[label] for r in scores_rows)
            ws.cell(row=total_row, column=col, value=total).font = Font(bold=True)
            pct_cell = ws.cell(row=pct_row, column=col, value=total / n)
            pct_cell.number_format = "0.0%"
            pct_cell.font = Font(bold=True)

    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 40
    for col in range(4, 4 + len(SCORES_COLUMN_ORDER)):
        ws.column_dimensions[get_column_letter(col)].width = 14


def write_annotated_excel(
    student_input_path: str | Path,
    output_path: str | Path,
    issues: List[Issue],
    grammar: Dict[str, Any],
    student_utts: Optional[List[Utterance]] = None,
    key_utts: Optional[List[Utterance]] = None,
    alignment: Optional[List[Tuple[Optional[int], Optional[int]]]] = None,
) -> None:
    """Create a copy of the student's workbook with highlights and inserted MISSING rows.

    Only the required columns (Time_Relative_hms, Observation, Behavior, Comment)
    plus any Modifier* columns are kept in the output - Observer XT exports
    include many extra columns (Date_Time_Absolute..., Event_Log, Event_Type,
    etc.) that aren't part of the coding scheme and were previously left in
    the annotated file untouched, even though prepare_dataframe() already
    ignores them for comparison purposes.

    If student_utts is provided (compare_files() returns it), every row gets
    an "Utterance #" value and every Review_Notes entry is prefixed with
    "[Utt N: "transcript"]" so a reviewer can tell at a glance which
    utterance an issue belongs to instead of having to reconstruct that by
    hand from row position.
    """
    wb = load_workbook(student_input_path)
    ws = wb.active

    header = [cell.value for cell in ws[1]]
    header_map = {str(v).strip(): i + 1 for i, v in enumerate(header) if v is not None}

    required = grammar["columns"]["required"]
    modifier_prefix = grammar["columns"]["modifier_columns"]["detect_by_prefix"]
    keep_names = set(required) | {
        name for name in header_map if str(name).startswith(modifier_prefix)
    }

    cols_to_delete = sorted(
        (idx for name, idx in header_map.items() if name not in keep_names),
        reverse=True,
    )
    for idx in cols_to_delete:
        ws.delete_cols(idx)

    # Recompute column positions now that unwanted columns are gone.
    header = [cell.value for cell in ws[1]]
    header_map = {str(v).strip(): i + 1 for i, v in enumerate(header) if v is not None}

    behavior_col = header_map.get("Behavior")
    comment_col = header_map.get("Comment")
    if behavior_col is None or comment_col is None:
        raise ValueError("Could not find Behavior/Comment columns in the student file.")

    # Map each original row index to its utterance, used to prefix Review_Notes
    # with "[Utt #N: transcript]" so a reviewer can tell which utterance an
    # issue belongs to without adding a separate column.
    row_to_utt: Dict[int, Utterance] = {}
    utt_by_uid: Dict[int, Utterance] = {}
    if student_utts:
        for utt in student_utts:
            utt_by_uid[utt.uid] = utt
            for r in utt.rows:
                row_to_utt[r.original_index] = utt

    # Add Review_Notes column if absent.
    review_col = header_map.get("Review_Notes")
    if review_col is None:
        review_col = ws.max_column + 1
        ws.cell(row=1, column=review_col).value = "Review_Notes"
        ws.cell(row=1, column=review_col).font = Font(bold=True)

    fills = {
        "red": PatternFill("solid", fgColor=grammar["colors"]["error"]),
        "orange": PatternFill("solid", fgColor=grammar["colors"]["usv_missing_note"]),
        "purple": PatternFill("solid", fgColor=grammar["colors"]["boundary_unclear"]),
    }

    # Map issue color hex back to fill by value.
    def fill_for(issue: Issue) -> PatternFill:
        if issue.color == grammar["colors"]["usv_missing_note"]:
            return fills["orange"]
        if issue.color == grammar["colors"]["boundary_unclear"]:
            return fills["purple"]
        return fills["red"]

    def context_prefix(issue: Issue) -> str:
        if issue.utterance_id is None:
            return ""
        utt = utt_by_uid.get(issue.utterance_id)
        text = utt.utterance_text if utt else ""
        label = f"[Utt #{issue.utterance_id}"
        if text:
            label += f': "{text}"'
        return label + "] "

    # Existing row highlights. DataFrame index 0 => Excel row 2.
    for issue in issues:
        if issue.row_index is None:
            continue
        excel_row = issue.row_index + 2
        f = fill_for(issue)
        for col in range(1, ws.max_column + 1):
            ws.cell(row=excel_row, column=col).fill = f
        old = clean_text(ws.cell(row=excel_row, column=review_col).value)
        note = context_prefix(issue) + issue.message
        ws.cell(row=excel_row, column=review_col).value = (old + " | " if old else "") + note

    # Insert missing rows bottom-up so row indices remain stable.
    insert_issues = [i for i in issues if i.insert_after_row_index is not None]
    insert_issues.sort(key=lambda x: x.insert_after_row_index or 0, reverse=True)
    for issue in insert_issues:
        insert_after_excel_row = (issue.insert_after_row_index or 0) + 2
        insert_at = insert_after_excel_row + 1
        ws.insert_rows(insert_at)
        for col in range(1, ws.max_column + 1):
            ws.cell(row=insert_at, column=col).fill = fill_for(issue)
        ws.cell(row=insert_at, column=behavior_col).value = issue.missing_behavior or "MISSING"
        ws.cell(row=insert_at, column=comment_col).value = issue.expected or issue.message
        ws.cell(row=insert_at, column=review_col).value = context_prefix(issue) + issue.message
        ws.cell(row=insert_at, column=behavior_col).font = Font(bold=True)

    # Basic readability.
    for col in range(1, ws.max_column + 1):
        letter = get_column_letter(col)
        ws.column_dimensions[letter].width = min(max(ws.column_dimensions[letter].width or 12, 14), 35)
    ws.column_dimensions[get_column_letter(comment_col)].width = 35
    ws.column_dimensions[get_column_letter(review_col)].width = 45

    # Scores sheet (second tab), mirroring the lab's manual score sheet.
    if student_utts is not None and key_utts is not None and alignment is not None:
        scores_rows = build_scores_rows(student_utts, key_utts, alignment, issues, grammar)
        write_scores_sheet(wb, scores_rows)

    wb.save(output_path)
